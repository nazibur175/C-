//save it using run.bat 

// @echo off
// test_gen >in
// my_sol <in >out
// brute <int >ok
// fc out ok
// if ErrorLevel 1 exit /b
// run


// brute.cpp
// Write your brute force solution here
// run using this command

//cd "D:\CPP\Stress_testing_windows\" ; if ($?) { g++ brute.cpp -o brute } ; if ($?) { .\brute }

    // int a,b;
    // cin>>a>>b;
    // cout<<a+b<<endl;


//my_sol.cpp
// Jei code likhe wrong khacci
//cd "D:\CPP\Stress_testing_windows\" ; if ($?) { g++ my_sol.cpp -o my_sol } ; if ($?) { .\my_sol }

    // int a,b;
    // cin>>a>>b;
    // if(a==2) a++;
    // cout<<a+b<<endl;


//test_gen.cpp
//cd "D:\CPP\Stress_testing_windows\" ; if ($?) { g++ test_gen.cpp -o test_gen } ; if ($?) { .\test_gen }

    // mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
    // int my_rand(int l, int r)
    // {
    // 	return uniform_int_distribution<int>(l, r) (rng);
    // }
    // void solve(){
    //     int a = my_rand(1,5);
    //     int b = my_rand(1,5);
    //     cout<<a<<" "<<b<<endl;

    // }


// Run the above three file
// Go to the File
// Open CMD (from the top)
// write run (press enter)
// Go to the in and out file (Here you can show the desired input)








